package com.codewithriddler.tenant_management_system.DTO;

public class LoginResponse {
    private String username;
    private String role;
    private String accessToken;
    private String refreshToken;

    // Private constructor
    private LoginResponse(Builder builder) {
        this.username = builder.username;
        this.role = builder.role;
        this.accessToken = builder.accessToken;
        this.refreshToken = builder.refreshToken;
    }

    // Getters
    public String getUsername() { return username; }
    public String getRole() { return role; }
    public String getAccessToken() { return accessToken; }
    public String getRefreshToken() { return refreshToken; }

    // Builder class
    public static class Builder {
        private String username;
        private String role;
        private String accessToken;
        private String refreshToken;

        public Builder username(String username) {
            this.username = username;
            return this;
        }

        public Builder role(String role) {
            this.role = role;
            return this;
        }

        public Builder accessToken(String accessToken) {
            this.accessToken = accessToken;
            return this;
        }

        public Builder refreshToken(String refreshToken) {
            this.refreshToken = refreshToken;
            return this;
        }

        public LoginResponse build() {
            return new LoginResponse(this);
        }
    }

    public static Builder builder() {
        return new Builder();
    }
}