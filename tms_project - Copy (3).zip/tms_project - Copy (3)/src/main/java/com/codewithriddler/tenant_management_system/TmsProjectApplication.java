package com.codewithriddler.tenant_management_system;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TmsProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TmsProjectApplication.class, args);
	}

}
