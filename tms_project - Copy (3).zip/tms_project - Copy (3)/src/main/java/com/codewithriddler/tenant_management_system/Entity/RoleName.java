package com.codewithriddler.tenant_management_system.Entity;

public enum RoleName {
    ADMIN, MANAGER, TENANT, OWNER
}
