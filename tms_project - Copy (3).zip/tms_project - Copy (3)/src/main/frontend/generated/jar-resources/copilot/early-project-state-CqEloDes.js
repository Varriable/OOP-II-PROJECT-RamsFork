const e = window.Vaadin.copilot._earlyProjectState;
if (!e)
  throw new Error("Tried to access early project state before it was initialized.");
export {
  e
};
