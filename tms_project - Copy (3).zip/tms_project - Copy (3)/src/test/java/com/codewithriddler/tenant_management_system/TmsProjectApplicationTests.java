package com.codewithriddler.tenant_management_system;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TmsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
